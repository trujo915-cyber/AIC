"""Transparent, local matching of documents against the loaded workbook."""
from __future__ import annotations

from difflib import SequenceMatcher
import re
import unicodedata

from .models import DocumentIdentification, DocumentMetadata, Practice, Student

STOPWORDS = {"informe", "laboratorio", "grupo", "practica", "práctica", "pdf", "final", "version"}
GROUP_RE = re.compile(r"(?:\b|[_-])g(?:rupo)?\s*[-_]?0*(\d{1,3})\b", re.IGNORECASE)
PRACTICE_NUMBER_RE = re.compile(r"(?:\b|[_-])p(?:ractica)?\s*[-_]?0*(\d{1,2})\b", re.IGNORECASE)


def normalize(value: str) -> str:
    raw = unicodedata.normalize("NFD", value.lower())
    raw = "".join(char for char in raw if unicodedata.category(char) != "Mn")
    return re.sub(r"[^a-z0-9]+", " ", raw).strip()


def _tokens(value: str) -> set[str]:
    return {token for token in normalize(value).split() if len(token) > 1 and token not in STOPWORDS}


def _student_score(student: Student, corpus: str) -> tuple[int, list[str]]:
    name_tokens = _tokens(student.name)
    corpus_tokens = _tokens(corpus)
    if not name_tokens:
        return 0, []
    overlap = name_tokens & corpus_tokens
    # The roster convention is surnames first, so preserve original token order.
    first_surname = normalize(student.name).split()[0] if normalize(student.name) else ""
    token_ratio = len(overlap) / len(name_tokens)
    string_ratio = SequenceMatcher(None, normalize(student.name), normalize(corpus)).ratio()
    score = int(min(100, 100 * (0.68 * token_ratio + 0.20 * string_ratio + (0.12 if first_surname in corpus_tokens else 0))))
    evidence = ["Coincidencia de nombre: " + ", ".join(sorted(overlap))] if overlap else []
    if student.group and normalize(student.group) in normalize(corpus):
        score = min(100, score + 5)
        evidence.append(f"Grupo mencionado: {student.group}")
    return score, evidence


def _practice_score(practice: Practice, corpus: str) -> tuple[int, list[str]]:
    practice_tokens = _tokens(practice.name)
    corpus_tokens = _tokens(corpus)
    overlap = practice_tokens & corpus_tokens
    score = int(100 * len(overlap) / len(practice_tokens)) if practice_tokens else 0
    return score, ["Coincidencia de práctica: " + ", ".join(sorted(overlap))] if overlap else []


def identify_document(document: DocumentMetadata, students: list[Student], practices: list[Practice]) -> DocumentIdentification:
    corpus = f"{document.filename} {document.extracted_text or document.text_preview or ''}"
    identification = DocumentIdentification(filename=document.filename)
    group_match = GROUP_RE.search(normalize(corpus))
    if group_match:
        identification.detected_group = group_match.group(1)
        identification.evidence.append(f"Grupo detectado: {identification.detected_group}")
    candidates = students
    if identification.detected_group:
        grouped = [student for student in students if normalize(str(student.group or "")) == identification.detected_group]
        if grouped:
            candidates = grouped
            identification.evidence.append("Búsqueda limitada al grupo detectado.")
    if candidates:
        student, score, evidence = max(((student, *_student_score(student, corpus)) for student in candidates), key=lambda item: item[1])
        if score >= 45:
            identification.student_name, identification.student_score = student.name, score
            identification.evidence.extend(evidence)
    if practices:
        practice, score, evidence = max(((practice, *_practice_score(practice, corpus)) for practice in practices), key=lambda item: item[1])
        number_match = PRACTICE_NUMBER_RE.search(normalize(document.filename))
        if number_match and int(number_match.group(1)) <= len(practices) and score < 50:
            practice = practices[int(number_match.group(1)) - 1]
            score = 75
            evidence.append(f"Referencia P{number_match.group(1)} en el nombre del archivo.")
        if score >= 25:
            identification.practice_name, identification.practice_score = practice.name, score
            identification.evidence.extend(evidence)
    return identification


def identify_documents(documents: list[DocumentMetadata], students: list[Student], practices: list[Practice]) -> list[DocumentIdentification]:
    return [identify_document(document, students, practices) for document in documents]
