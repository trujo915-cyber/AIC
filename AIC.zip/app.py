from __future__ import annotations

import pandas as pd
import streamlit as st

from modules.document_engine import inspect_document
from modules.excel_reader import analyze_workbook
from modules.matcher import identify_documents

st.set_page_config(page_title="AIC | Asistente Inteligente de Calificación", page_icon="📘", layout="wide")

st.markdown("""
<style>
    .block-container {max-width: 1200px; padding-top: 2rem;}
    [data-testid="stMetric"] {background: #f4f8fc; border-radius: .7rem; padding: .8rem;}
    .section-note {color: #5f6f7e;}
</style>
""", unsafe_allow_html=True)


def init_state() -> None:
    for key, default in {"workbook": None, "knowledge": {}, "documents": [], "identifications": [], "document_sources": {}}.items():
        if key not in st.session_state:
            st.session_state[key] = default


def metadata_table(items):
    return pd.DataFrame([{
        "Documento": item.filename,
        "Clasificación sugerida": item.category,
        "Confianza": item.confidence,
        "Tipo": item.file_type,
        "Páginas": item.pages or "—",
        "Texto embebido": "Sí" if item.embedded_text_available else ("No" if item.embedded_text_available is False else "—"),
        "Dimensiones": f"{item.image_width} × {item.image_height}" if item.image_width else "—",
        "Tamaño (KB)": round(item.size_bytes / 1024, 1),
    } for item in items])


def identification_table(items):
    return pd.DataFrame([{
        "Documento": item.filename,
        "Estudiante sugerido": item.student_name or "No identificado",
        "Confianza estudiante": f"{item.student_score}%" if item.student_name else "—",
        "Práctica sugerida": item.practice_name or "No identificada",
        "Confianza práctica": f"{item.practice_score}%" if item.practice_name else "—",
        "Grupo detectado": item.detected_group or "—",
        "Estado": "Requiere confirmación" if item.needs_review else "Sugerencia sólida",
    } for item in items])


init_state()
st.title("📘 AIC")
st.caption("Asistente Inteligente de Calificación · v0.3.0-alpha")
st.info("Esta versión propone coincidencias revisables. No califica ni modifica el Excel.")

tab_excel, tab_knowledge, tab_documents, tab_review = st.tabs([
    "1 · Calificaciones", "2 · Base de conocimiento", "3 · Documentos a procesar", "4 · Revisión"
])

with tab_excel:
    st.subheader("Cargar archivo de calificaciones")
    uploaded_excel = st.file_uploader("Libro Excel del grupo", type=["xlsx"], key="excel_upload")
    if uploaded_excel:
        try:
            st.session_state.workbook = analyze_workbook(uploaded_excel.getvalue(), uploaded_excel.name)
        except Exception as exc:
            st.error(f"No se pudo analizar el libro: {exc}")
    analysis = st.session_state.workbook
    if analysis:
        cols = st.columns(4)
        cols[0].metric("Estudiantes", len(analysis.students))
        cols[1].metric("Prácticas", len(analysis.practices))
        cols[2].metric("Rubros", analysis.evaluation_columns)
        cols[3].metric("Hojas", len(analysis.sheets))
        st.caption(f"Hoja analizada: **{analysis.active_sheet}** · encabezado detectado: fila **{analysis.header_row or 'no identificado'}**")
        if analysis.warnings:
            for warning in analysis.warnings:
                st.warning(warning)
        if analysis.practices:
            st.dataframe(pd.DataFrame([{
                "Práctica detectada": p.name,
                "Rubros / columnas": ", ".join(f"{k} ({v})" for k, v in p.columns.items())
            } for p in analysis.practices]), use_container_width=True, hide_index=True)
        with st.expander("Ver estudiantes detectados"):
            st.dataframe(pd.DataFrame([s.__dict__ for s in analysis.students]), use_container_width=True, hide_index=True)
    else:
        st.caption("Carga el Excel para identificar estudiantes, prácticas y rubros de evaluación.")

with tab_knowledge:
    st.subheader("Base de conocimiento")
    st.markdown("<p class='section-note'>Estos archivos se mantienen separados de los documentos a procesar y se usarán como contexto en la futura evaluación asistida.</p>", unsafe_allow_html=True)
    knowledge_uploads = {
        "Guías de práctica": st.file_uploader("Guías de práctica", type=["pdf", "docx", "jpg", "jpeg", "png"], accept_multiple_files=True, key="guides"),
        "Rúbricas": st.file_uploader("Rúbricas", type=["pdf", "docx", "jpg", "jpeg", "png"], accept_multiple_files=True, key="rubrics"),
        "Ejemplos ya calificados": st.file_uploader("Ejemplos ya calificados", type=["pdf", "jpg", "jpeg", "png"], accept_multiple_files=True, key="examples"),
    }
    st.session_state.knowledge = {category: [file.name for file in files] for category, files in knowledge_uploads.items() if files}
    criteria = st.text_area("Criterios u observaciones de Carla (texto libre)", placeholder="Ej.: Las conclusiones deben responder a los objetivos; descontar 0,2 si no hay recomendaciones claras.")
    if criteria:
        st.session_state.knowledge["Criterios de texto"] = [criteria]
    if st.session_state.knowledge:
        st.success("Base de conocimiento cargada para esta sesión.")
        for category, files in st.session_state.knowledge.items():
            st.caption(f"**{category}:** {len(files)} elemento(s)")

with tab_documents:
    st.subheader("Documentos a procesar")
    st.markdown("<p class='section-note'>Carga informes digitales, escaneos o fotos. AIC inspecciona los metadatos de manera local y propone una clasificación revisable.</p>", unsafe_allow_html=True)
    uploads = st.file_uploader("PDF, JPG, JPEG o PNG", type=["pdf", "jpg", "jpeg", "png"], accept_multiple_files=True, key="process_documents")
    if uploads:
        with st.spinner("Inspeccionando documentos…"):
            st.session_state.documents = [inspect_document(upload) for upload in uploads]
            st.session_state.document_sources = {upload.name: upload.getvalue() for upload in uploads}
            st.session_state.identifications = []
        st.success(f"Se analizaron {len(st.session_state.documents)} documento(s).")
    if st.session_state.documents:
        st.dataframe(metadata_table(st.session_state.documents), use_container_width=True, hide_index=True)
        for item in st.session_state.documents:
            with st.expander(f"{item.filename} · {item.category}"):
                st.write(f"**Señales:** {' · '.join(item.signals) if item.signals else 'Sin señales suficientes.'}")
                if item.text_preview:
                    st.text_area("Vista previa de texto embebido", item.text_preview, height=120, disabled=True, key=f"preview_{item.filename}")
                if item.error:
                    st.error(f"No se pudo inspeccionar completamente: {item.error}")

with tab_review:
    st.subheader("Revisión de lote")
    documents = st.session_state.documents
    analysis = st.session_state.workbook
    if not documents:
        st.info("Carga documentos en el módulo anterior para generar la revisión.")
    elif not analysis:
        st.info("Carga primero el archivo de calificaciones para identificar estudiantes y prácticas.")
    else:
        if st.button("Buscar coincidencias en el Excel", type="primary") or not st.session_state.identifications:
            st.session_state.identifications = identify_documents(documents, analysis.students, analysis.practices)
        identifications = st.session_state.identifications
        col1, col2, col3 = st.columns(3)
        col1.metric("Documentos", len(documents))
        col2.metric("Estudiantes sugeridos", sum(item.student_name is not None for item in identifications))
        col3.metric("Por confirmar", sum(item.needs_review for item in identifications))
        st.dataframe(identification_table(identifications), use_container_width=True, hide_index=True)

        st.subheader("Confirmación visual")
        selected_name = st.selectbox("Documento", [item.filename for item in identifications])
        selected = next(item for item in identifications if item.filename == selected_name)
        document = next(item for item in documents if item.filename == selected_name)
        left, right = st.columns([3, 2])
        with left:
            source = st.session_state.document_sources.get(selected_name)
            if source and document.file_type.upper() in {"PNG", "JPEG", "JPG"}:
                st.image(source, caption=selected_name, use_container_width=True)
            elif document.text_preview:
                st.text_area("Texto extraído del PDF", document.text_preview, height=250, disabled=True)
            else:
                st.caption("No hay vista previa disponible para este formato.")
        with right:
            student_options = ["No identificado"] + [student.name for student in analysis.students]
            practice_options = ["No identificada"] + [practice.name for practice in analysis.practices]
            st.selectbox("Estudiante", student_options, index=student_options.index(selected.student_name) if selected.student_name in student_options else 0, key=f"student_{selected_name}")
            st.selectbox("Práctica", practice_options, index=practice_options.index(selected.practice_name) if selected.practice_name in practice_options else 0, key=f"practice_{selected_name}")
            st.caption("Evidencia: " + (" · ".join(selected.evidence) or "No se encontraron señales suficientes."))
            st.caption("Aún no se guarda ni se modifica Excel.")
        st.warning("Sprint 3 solo prepara coincidencias revisables. La escritura segura de notas será un sprint posterior.")

st.divider()
st.caption("AIC v0.3.0-alpha · Identificación local · Estado seguro: solo lectura")
