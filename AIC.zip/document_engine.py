"""Clasificación local y extracción de metadatos, sin servicios externos."""
from __future__ import annotations

from io import BytesIO
from pathlib import Path
import re

try:  # PyMuPDF is installed from requirements in the deployed application.
    import fitz
except ImportError:  # Keep the interface usable while dependencies are being installed.
    fitz = None

try:
    from PIL import Image
except ImportError:
    Image = None

from .models import DocumentMetadata

REPORT_WORDS = ("informe", "introduccion", "introducción", "metodologia", "metodología", "resultados", "conclusiones", "abstract", "resumen")
QUIZ_WORDS = ("coloquio", "cuestionario", "pregunta", "evaluacion", "evaluación", "quiz")


def _classify_pdf(filename: str, text: str) -> tuple[str, str, list[str]]:
    corpus = f"{filename} {text}".lower()
    signals: list[str] = []
    report_hits = [word for word in REPORT_WORDS if word in corpus]
    quiz_hits = [word for word in QUIZ_WORDS if word in corpus]
    if report_hits:
        signals.append("Señales de informe: " + ", ".join(report_hits[:3]))
    if quiz_hits:
        signals.append("Señales de coloquio: " + ", ".join(quiz_hits[:3]))
    if len(report_hits) >= len(quiz_hits) and report_hits:
        return "Informe PDF", "Sugerencia alta" if len(report_hits) >= 2 else "Sugerencia media", signals
    if quiz_hits:
        return "Cuestionario PDF", "Sugerencia media", signals
    return "PDF sin clasificar", "Por revisar", signals


def inspect_document(uploaded_file) -> DocumentMetadata:
    data = uploaded_file.getvalue()
    filename = uploaded_file.name
    suffix = Path(filename).suffix.lower()
    if suffix == ".pdf":
        if fitz is None:
            return DocumentMetadata(
                filename, "PDF pendiente de inspección", "PDF", len(data),
                confidence="Por revisar",
                signals=["Instala PyMuPDF para extraer páginas y texto embebido."],
            )
        try:
            pdf = fitz.open(stream=data, filetype="pdf")
            text = "".join(page.get_text("text") for page in pdf)
            category, confidence, signals = _classify_pdf(filename, text)
            return DocumentMetadata(
                filename=filename, category=category, file_type="PDF", size_bytes=len(data),
                pages=pdf.page_count, embedded_text_available=bool(text.strip()),
                text_preview=(re.sub(r"\s+", " ", text).strip()[:450] or None),
                confidence=confidence, signals=signals, extracted_text=text,
            )
        except Exception as exc:
            return DocumentMetadata(filename, "Documento desconocido", "PDF", len(data), error=str(exc))
    if suffix in {".jpg", ".jpeg", ".png"}:
        if Image is None:
            return DocumentMetadata(
                filename, "Imagen / posible coloquio", suffix[1:].upper(), len(data),
                confidence="Por revisar",
                signals=["Instala Pillow para leer dimensiones de imagen."],
            )
        try:
            image = Image.open(BytesIO(data))
            return DocumentMetadata(
                filename=filename, category="Imagen / posible coloquio", file_type=image.format or suffix[1:].upper(),
                size_bytes=len(data), image_width=image.width, image_height=image.height,
                confidence="Por revisar", signals=["La clasificación precisa requerirá OCR en una próxima versión."],
            )
        except Exception as exc:
            return DocumentMetadata(filename, "Documento desconocido", suffix[1:].upper(), len(data), error=str(exc))
    return DocumentMetadata(filename, "Documento desconocido", suffix[1:].upper() or "desconocido", len(data))
