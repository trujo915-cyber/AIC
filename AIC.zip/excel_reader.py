"""Lectura tolerante a cambios de estructura para libros de calificaciones."""
from __future__ import annotations

from io import BytesIO
import re
import unicodedata

from openpyxl import load_workbook

from .models import Practice, Student, WorkbookAnalysis

RUBRIC_RE = re.compile(r"^(C|P|I|T)\s*\d*$", re.IGNORECASE)
NAME_MARKERS = {"nombre", "estudiante", "apellidos y nombres", "nombres"}
CODE_MARKERS = {"codigo", "código", "id", "cedula", "cédula"}
GROUP_MARKERS = {"grupo", "paralelo", "equipo"}


def _text(value: object) -> str:
    return str(value).strip() if value is not None else ""


def _normalise(value: object) -> str:
    raw = unicodedata.normalize("NFD", _text(value).lower())
    return "".join(ch for ch in raw if unicodedata.category(ch) != "Mn")


def _find_header(ws) -> tuple[int | None, dict[str, int]]:
    for row in range(1, min(ws.max_row, 35) + 1):
        cells = {_normalise(ws.cell(row, col).value): col for col in range(1, ws.max_column + 1)}
        found: dict[str, int] = {}
        for marker in NAME_MARKERS:
            if marker in cells:
                found["name"] = cells[marker]
                break
        if "name" in found:
            for marker in CODE_MARKERS:
                if marker in cells:
                    found["code"] = cells[marker]
                    break
            for marker in GROUP_MARKERS:
                if marker in cells:
                    found["group"] = cells[marker]
                    break
            return row, found
    return None, {}


def _find_practices(ws, header_row: int | None) -> list[Practice]:
    rubrics: list[tuple[int, int, str]] = []
    for row in range(1, min(ws.max_row, 35) + 1):
        for col in range(1, ws.max_column + 1):
            candidate = _text(ws.cell(row, col).value).upper().replace(" ", "")
            if RUBRIC_RE.fullmatch(candidate):
                rubrics.append((row, col, candidate))
    practices: dict[str, Practice] = {}
    for rubric_row, col, rubric in rubrics:
        title = ""
        # Prefer a merged/title cell above the rubric, then scan left on the same title row.
        for title_row in range(rubric_row - 1, max(0, rubric_row - 5), -1):
            for scan_col in range(col, 0, -1):
                value = _text(ws.cell(title_row, scan_col).value)
                if value and not RUBRIC_RE.fullmatch(value.upper().replace(" ", "")):
                    title = value
                    break
            if title:
                break
        if not title:
            title = f"Práctica asociada a columna {col}"
        practice = practices.setdefault(title, Practice(name=title))
        practice.columns[rubric] = col
    return list(practices.values())


def analyze_workbook(content: bytes, filename: str) -> WorkbookAnalysis:
    workbook = load_workbook(BytesIO(content), data_only=False, read_only=False)
    ws = workbook.active
    header_row, columns = _find_header(ws)
    students: list[Student] = []
    warnings: list[str] = []
    if header_row and columns.get("name"):
        blank_streak = 0
        for row in range(header_row + 1, ws.max_row + 1):
            name = _text(ws.cell(row, columns["name"]).value)
            if not name:
                blank_streak += 1
                if blank_streak >= 3:
                    break
                continue
            blank_streak = 0
            students.append(Student(
                name=name,
                code=_text(ws.cell(row, columns["code"]).value) if columns.get("code") else None,
                group=_text(ws.cell(row, columns["group"]).value) if columns.get("group") else None,
                row=row,
            ))
    else:
        warnings.append("No se identificó con certeza la columna de nombres de estudiantes.")
    practices = _find_practices(ws, header_row)
    if not practices:
        warnings.append("No se detectaron rubros C, P, I o T en las primeras filas del libro.")
    return WorkbookAnalysis(
        filename=filename,
        sheets=workbook.sheetnames,
        active_sheet=ws.title,
        header_row=header_row,
        students=students,
        practices=practices,
        evaluation_columns=sum(len(practice.columns) for practice in practices),
        warnings=warnings,
    )
