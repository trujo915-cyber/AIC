# AIC — Asistente Inteligente de Calificación

Aplicación web para organizar evaluaciones de laboratorio y analizar de forma segura los archivos de calificaciones. Esta entrega corresponde a **v0.3.0-alpha**: conserva el análisis dinámico de Excel y el Motor Documental, e incorpora identificación local revisable.

## Capacidades actuales

- Carga y analiza libros Excel sin depender de posiciones fijas.
- Detecta estudiantes, prácticas y rubros de evaluación cuando están presentes.
- Permite cargar múltiples PDF, JPG, JPEG y PNG.
- Separa la base de conocimiento (guías, rúbricas, ejemplos y criterios) de los documentos por procesar.
- Clasifica documentos de forma conservadora y muestra sus metadatos.
- Incluye una pantalla de revisión preparada para las fases de identificación y calificación asistida.
- Sugiere estudiante, grupo y práctica a partir del nombre del archivo y del texto embebido del PDF; cada sugerencia se puede comprobar visualmente y editar antes de cualquier acción futura.

## Ejecutar localmente

Requiere Python 3.10 o posterior.

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
streamlit run app.py
```

La aplicación no guarda de forma persistente los documentos cargados; los datos viven en la sesión del navegador. Para acceso desde móvil sin depender de una laptop encendida, el siguiente paso de despliegue es Streamlit Community Cloud desde un repositorio GitHub privado o público según la política de privacidad institucional.

## Límites de v0.3.0-alpha

No califica, no realiza OCR manuscrito y no modifica Excel todavía. La identificación usa coincidencia local explicable, por lo que siempre se muestra como sugerencia revisable.
