from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass
class Student:
    name: str
    code: str | None = None
    group: str | None = None
    row: int | None = None


@dataclass
class Practice:
    name: str
    columns: dict[str, int] = field(default_factory=dict)


@dataclass
class WorkbookAnalysis:
    filename: str
    sheets: list[str]
    active_sheet: str
    header_row: int | None
    students: list[Student]
    practices: list[Practice]
    evaluation_columns: int
    warnings: list[str] = field(default_factory=list)


@dataclass
class DocumentMetadata:
    filename: str
    category: str
    file_type: str
    size_bytes: int
    pages: int | None = None
    embedded_text_available: bool | None = None
    text_preview: str | None = None
    image_width: int | None = None
    image_height: int | None = None
    confidence: str = "Por revisar"
    signals: list[str] = field(default_factory=list)
    error: str | None = None
    extracted_text: str = field(default="", repr=False)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class DocumentIdentification:
    """A suggested document-to-workbook link; it must be reviewed by a user."""

    filename: str
    student_name: str | None = None
    student_score: int = 0
    practice_name: str | None = None
    practice_score: int = 0
    detected_group: str | None = None
    evidence: list[str] = field(default_factory=list)

    @property
    def needs_review(self) -> bool:
        return self.student_score < 85 or self.practice_score < 85
