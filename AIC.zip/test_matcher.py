import unittest

from modules.matcher import identify_document
from modules.models import DocumentMetadata, Practice, Student


class MatcherTests(unittest.TestCase):
    def test_identifies_student_practice_and_group_from_filename_and_text(self):
        document = DocumentMetadata(
            filename="83224_DANIEL_SEBASTIAN_ACUNA_SALAZAR_P2_G7.pdf",
            category="Informe PDF",
            file_type="PDF",
            size_bytes=1,
            extracted_text="Informe: Intercambiador de tubos concentricos",
        )
        result = identify_document(
            document,
            [Student("ACUNA SALAZAR DANIEL SEBASTIAN", group="7")],
            [Practice("Ley Stephan Boltzmann"), Practice("Intercambiador de tubos concentricos")],
        )
        self.assertEqual(result.student_name, "ACUNA SALAZAR DANIEL SEBASTIAN")
        self.assertEqual(result.practice_name, "Intercambiador de tubos concentricos")
        self.assertEqual(result.detected_group, "7")


if __name__ == "__main__":
    unittest.main()
